<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProposalController extends Controller
{
    public function insert(Request $request)
    {
        // DB::table('proposals')
    }
}
