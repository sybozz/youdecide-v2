<ul>
  <li><a href="{{ url('proposals/recent') }}">Recent proposals</a></li>
  <li><a href="{{ url('proposals/no-vote') }}">No votes</a></li>
  <li><a href="{{ url('proposals/results') }}">Results</a></li>
</ul>
