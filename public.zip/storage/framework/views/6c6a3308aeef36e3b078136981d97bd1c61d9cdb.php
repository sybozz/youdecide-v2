<?php $__env->startSection('title', 'Proposa details'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="card">
      <div class="header">
          <h4 class="title">Update proposal</h4>
      </div>
      <hr>
      <div class="row">
        <form class="form-horizontal" method="POST" action="<?php echo e(url('proposal/update/'.$proposal->id)); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="title" class="col-md-3 control-label">Title</label>
                <div class="col-md-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e($proposal->title); ?>" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label for="description" class="col-md-3 control-label">Description</label>
                <div class="col-md-6">
                    <textarea name="description" id="" rows="10" class="form-control"><?php echo $proposal->description; ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                    <button type="submit" class="btn btn-primary">
                        Update
                    </button>
                </div>
            </div>
        </form>
      </div>


    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>