<?php $__env->startSection('title', 'Timeline'); ?>
<?php $__env->startSection('pageHeader', 'Timeline'); ?>

<?php $__env->startSection('content'); ?>
  <ul class="list-inline text-center">
    <li><a href="<?php echo e(url('/activity/published')); ?>">Published</a></li>
    <li c;><a href="<?php echo e(url('/activity/pending')); ?>">Pending</a></li>
    <li><a href="<?php echo e(url('/activity/unpublished')); ?>" class="text-muted">Unpublished</a></li>
  </ul>
  <div class="timeline-content">
    <div class="list-group">
      <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(url('proposal/view/'.$proposal->id)); ?>" class="list-group-item">
        <h4 class="list-group-item-heading"><?php echo e($proposal->title); ?></h4>
        <p class="list-group-item-text text-muted">Created on: <?php echo e($proposal->created_at); ?></p>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>