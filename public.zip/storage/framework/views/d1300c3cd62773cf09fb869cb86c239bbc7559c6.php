<?php $__env->startSection('title', 'Proposals'); ?>
<?php $__env->startSection('contentHeader', 'Top voted'); ?>


<?php $__env->startSection('mainContent'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Table With Full Features</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Proposal ID.</th>
                <th>Title</th>
                <th>Published on</th>
                <th>Votes count</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($proposal->proposal_id); ?></td>
                <td><a href="<?php echo e(url('proposal/display/'.$proposal->id)); ?>"><?php echo e($proposal->title); ?></a></td>
                <td><?php echo e($proposal->updated_at); ?></td>
                <td><?php echo e($proposal->total_votes); ?></td>
                <td><?php echo e($proposal->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<!-- /.box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>