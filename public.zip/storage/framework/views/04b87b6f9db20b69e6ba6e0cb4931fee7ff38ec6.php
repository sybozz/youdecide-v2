<?php $__env->startSection('title', 'Proposa details'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="card">
      <div class="header">
          <h4 class="title"><?php echo e($proposal->title); ?></h4>
          <span class="text-muted">Created on: <?php echo e($proposal->created_at); ?></span>
      </div>

      <hr>

      <div class="row">
        <div class="col-md-6 col-md-offset-3">
          <?php echo $proposal->description; ?>

        </div>
      </div>

      <hr>

      <div class="row">
        <div class="col-md-6 col-md-offset-3">
          <p class="text-right">
            <a href="<?php echo e(url('proposal/approve/'.$proposal->id)); ?>" onclick="confirm('Are you sure to publish it?')" class="btn btn-success"><i class="fa fa-check"></i></a>
            <a href="<?php echo e(url('proposal/disapprove/'.$proposal->id )); ?>" onclick="confirm('Are you sure to block it?')" class="btn btn-warning"><i class="fa fa-ban"></i></a>
          </p>
        </div>
      </div>




    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>