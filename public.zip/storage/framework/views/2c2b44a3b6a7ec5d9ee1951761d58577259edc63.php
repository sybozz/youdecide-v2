<?php $__env->startSection('title', 'Proposals'); ?>
<?php $__env->startSection('contentHeader', 'Top voted'); ?>


<?php $__env->startSection('mainContent'); ?>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"><?php echo e($proposal->title); ?></h3>
        </div>
        <hr>
        <!-- /.box-header -->
        <div class="box-body">
            <?php echo $proposal->description; ?>

        </div>
        <!-- /.box-body -->
        <hr>
        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-info pull-right">Back</a>
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>