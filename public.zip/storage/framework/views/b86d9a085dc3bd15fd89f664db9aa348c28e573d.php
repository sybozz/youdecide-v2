<?php $__env->startSection('title', 'Results'); ?>
<?php $__env->startSection('pageHeader', 'Results'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-9">

            <div class="item-list">
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="item-card">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="item-content">
                                    <h3><a href="<?php echo e(url('proposal/view/'.$proposal->id)); ?>"><?php echo e($proposal->title); ?></a></h3>
                                    <?php echo $proposal->description; ?>

                                    <div class="item-content-meta">
                                        <strong class="text-muted">Published on: <?php echo e($proposal->updated_at); ?></strong>
                                        <span class="pull-right">
                                            <span class="text-right text-muted">Total votes: <span class="badge"><?php echo e($proposal->total_votes); ?></span></span>
                                        </span>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
        <div class="col-md-3">
            <?php echo $__env->make('website.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>