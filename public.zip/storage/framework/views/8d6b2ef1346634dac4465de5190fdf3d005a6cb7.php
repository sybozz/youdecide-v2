<?php $__env->startSection('title', 'View proposal'); ?>
<?php $__env->startSection('pageHeader', $proposal->title); ?>

<?php $__env->startSection('content'); ?>
<p class="text-center text-muted">Created on: <?php echo e($proposal->created_at); ?></p>
<div class="proposal-single">
  <?php echo $proposal->description; ?>

</div>
<hr>
<div class="item-content-meta">
    <strong class="text-muted">Published on: <?php echo e($proposal->updated_at); ?></strong>
    <span class="pull-right">
        <!-- <a href="<?php echo e(url('proposal/like/'.$proposal->id)); ?>" class="btn btn-info btn-sm">Like</a>
        | -->
        <a href="<?php echo e(url('proposal/vote/'.$proposal->id)); ?>" class="btn btn-success btn-sm">Vote <i class="fa fa-plus"></i></a>
        |
        <span class="text-right text-muted">Total votes: <span class="badge"><?php echo e($proposal->total_votes); ?></span></span>
    </span>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>