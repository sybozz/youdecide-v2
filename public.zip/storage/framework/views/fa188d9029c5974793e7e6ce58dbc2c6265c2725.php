<ul>
  <li><a href="<?php echo e(url('proposals/recent')); ?>">Recent proposals</a></li>
  <li><a href="<?php echo e(url('proposals/no-vote')); ?>">No votes</a></li>
  <li><a href="<?php echo e(url('proposals/results')); ?>">Results</a></li>
</ul>
