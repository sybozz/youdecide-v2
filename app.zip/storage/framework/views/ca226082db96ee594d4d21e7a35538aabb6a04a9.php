<div class="profile-cover">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="text-center">
                    <img src="http://via.placeholder.com/150x150" class="img-circle" alt="">
                </div>
                <p class="text-center">
                    <strong><?php echo e(Auth::user()->name); ?></strong>
                    |
                    <span>Student</span>
                </p>
            </div>
        </div>
    </div>
</div>