<?php $__env->startSection('title', 'View proposal'); ?>
<?php $__env->startSection('pageHeader', $proposal->title); ?>

<?php $__env->startSection('content'); ?>
<p class="text-center text-muted">Created on: <?php echo e($proposal->created_at); ?></p>
<div class="proposal-single">
  <?php echo $proposal->description; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>