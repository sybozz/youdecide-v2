<?php $__env->startSection('title', 'Timeline'); ?>
<?php $__env->startSection('pageHeader', 'Timeline'); ?>

<?php $__env->startSection('content'); ?>
  <ul class="list-inline text-center">
    <li><a href="<?php echo e(url('/activity/published')); ?>">Published</a></li>
    <li c;><a href="<?php echo e(url('/activity/pending')); ?>" class="text-muted">Pending</a></li>
    <li><a href="<?php echo e(url('/activity/unpublished')); ?>">Unpublished</a></li>
  </ul>
  <div class="timeline-content">
    <div class="list-group">
      <a href="#" class="list-group-item">
        <h4 class="list-group-item-heading">List group item heading</h4>
        <p class="list-group-item-text text-muted">Created on: 12/08/2016</p>
      </a>
      <a href="#" class="list-group-item">
        <h4 class="list-group-item-heading">List group item heading</h4>
        <p class="list-group-item-text text-muted">Created on: 12/08/2016</p>
      </a>
      </a>
      <a href="#" class="list-group-item">
        <h4 class="list-group-item-heading">List group item heading</h4>
        <p class="list-group-item-text text-muted">Created on: 12/08/2016</p>
      </a>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>