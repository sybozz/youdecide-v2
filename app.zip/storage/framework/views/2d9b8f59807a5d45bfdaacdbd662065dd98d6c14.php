<?php $__env->startSection('title', 'Recent proposals'); ?>
<?php $__env->startSection('pageHeader', 'Recent proposals'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-9">

            <div class="item-list">
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="item-card">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="item-content">
                                    <h3><a href="<?php echo e(url('proposal/view/'.$proposal->id)); ?>"><?php echo e($proposal->title); ?></a></h3>
                                    <?php echo $proposal->description; ?>

                                    <div class="item-content-meta">
                                        <strong class="text-muted">Published on: <?php echo e($proposal->updated_at); ?></strong>
                                        <span class="pull-right">
                                            <!-- <a href="<?php echo e(url('proposal/like/'.$proposal->id)); ?>" class="btn btn-info btn-sm">Like</a>
                                            | -->
                                            <a href="<?php echo e(url('proposal/vote/'.$proposal->id)); ?>" class="btn btn-success btn-sm">Vote +</a>
                                            |
                                            <span class="text-right text-muted">Total votes: <?php echo e($proposal->votes); ?></span>
                                        </span>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
        <div class="col-md-3">
            <ul>
                <li><a href="#">Recent proposals</a></li>
                <li><a href="#">No votes</a></li>
                <li><a href="#">Results</a></li>
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>