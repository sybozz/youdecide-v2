<?php $__env->startSection('title', 'Pending proposals'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Pending proposals</h4>
                <p class="category">Waiting for your actions.</p>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                    <th>ID</th>
                    <th width="50%">Title</th>
                    <th>Created on</th>
                    <th>By</th>
                    <th>Actions</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($proposal->id); ?></td>
                        <td><a href="<?php echo e(url('proposal/detail/'.$proposal->id)); ?>"><?php echo e($proposal->title); ?></a></td>
                        <td><?php echo e($proposal->created_at); ?></td>
                        <td><?php echo e($proposal->name); ?></td>
                        <td>
                            <a href="<?php echo e(url('proposal/approve/'.$proposal->id)); ?>" onclick="confirm('Are you sure to publish it?')" class="btn btn-success btn-xsm"><i class="fa fa-check"></i></a>
                            <a href="<?php echo e(url('proposal/disapprove/'.$proposal->id )); ?>" onclick="confirm('Are you sure to block it?')" class="btn btn-warning btn-xsm"><i class="fa fa-ban"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>