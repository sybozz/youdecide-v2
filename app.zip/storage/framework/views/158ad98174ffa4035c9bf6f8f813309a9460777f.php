<?php $__env->startSection('title', 'Recent proposals'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-8">
            <div class="page-header">
                <h2>Recent proposals</h2>
            </div>
            <div class="item-list">
                <ul class="list-unstyled">
                    <li>
                        <div class="profile-pic pull-left">
                            <img src="http://via.placeholder.com/75x75" alt="" class="img-circle">
                        </div>
                        <div class="item-content">
                            <h3>Proposal title</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus aperiam commodi earum impedit laborum obcaecati porro unde. Architecto commodi doloribus expedita ipsam odit, quae qui quidem temporibus ullam voluptas voluptatem!</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>