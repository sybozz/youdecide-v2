<?php $__env->startSection('title', 'Timeline'); ?>
<?php $__env->startSection('pageHeader', 'Timeline'); ?>

<?php $__env->startSection('content'); ?>

    <div class="timeline-content">
      
      <p class="text-muted text-center">
          Total proposals: 35
          |
          Published: 20
          |
          Unpublished: 10
          |
          Pending: 5
      </p>

      <div class="btn-group btn-group-justified">
        <a href="#" class="btn btn-default active">Published</a>
        <a href="#" class="btn btn-default">Pending</a>
        <a href="#" class="btn btn-default">Unpublished</a>
      </div>

      <br>

      <div class="list-group">
        <a href="#" class="list-group-item">
          <span class="badge">14</span>
          <h4 class="list-group-item-heading">List group item heading</h4>
          <p class="list-group-item-text text-muted">Published on: 12/08/2016</p>
        </a>
        <a href="#" class="list-group-item">
          <span class="badge">45</span>
          <h4 class="list-group-item-heading">List group item heading</h4>
          <p class="list-group-item-text">Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.</p>
        </a>
        </a>
        <a href="#" class="list-group-item">
          <span class="badge">87</span>
          <h4 class="list-group-item-heading">List group item heading</h4>
          <p class="list-group-item-text">Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.</p>
        </a>
      </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>