<?php $__env->startSection('title', 'Proposa details'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="card">
      <div class="header">
          <h4 class="title"><?php echo e($proposal->title); ?></h4>
      </div>
      <hr>

      <div class="content">

        <h4><u>Proposal description</u></h5>
        <?php echo $proposal->description; ?>

        <!-- decoded HTML CSS  -->

        <hr>
        <div class="meta">
          <p class="text-muted">
            Created by: <?php echo e($proposal->name); ?> <br>
            Created on: <?php echo e($proposal->created_at); ?>

          </p>
        </div>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>