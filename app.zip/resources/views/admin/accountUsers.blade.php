@extends('admin.app')
@section('title', 'Accounts')
@section('contentHeader', 'Users')


@section('mainContent')
<div class="box">
  <div class="box-header">
    <h3 class="box-title">Data Table With Full Features</h3>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
    <table id="example1" class="table table-bordered table-striped">
      <thead>
      <tr>
        <th>Account ID.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Member since</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
      </thead>
      <tbody>
      @foreach( $users as $user )
      <tr>
        <td>{{ $user->id }}</td>
        <td>{{ $user->name }}</td>
        <td>{{ $user->email }}</td>
        <td>{{ $user->created_at }}</td>
        <td>Active</td>
        <td>
          <a href="#" class="btn btn-danger btn-sm">Block</a>
        </td>
      </tr>
      @endforeach
      </tbody>
    </table>
  </div>
  <!-- /.box-body -->
</div>
<!-- /.box -->

@endsection
